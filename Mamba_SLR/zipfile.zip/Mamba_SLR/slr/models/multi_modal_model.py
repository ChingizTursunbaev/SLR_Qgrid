# slr/models/multi_modal_model.py

import torch
import torch.nn as nn
from .model import Model # Reuse the existing Vision Transformer

class MultiModalMamba(nn.Module):
    def __init__(self, img_cfg, qgrid_cfg, kp_cfg, num_classes, fusion_cfg):
        super().__init__()

        # 1. Low-Frequency Encoder (Images)
        self.image_encoder = Model(**img_cfg, num_classes=None)

        # 2. High-Frequency Encoder (Qgrid)
        # We use another instance of the base 'Model', assuming it's a Mamba-based variant
        self.qgrid_encoder = Model(**qgrid_cfg, num_classes=None)

        # 3. Keypoint Encoder (a simple MLP for demonstration)
        self.keypoint_encoder = nn.Sequential(
            nn.Linear(kp_cfg['input_dim'], kp_cfg['model_dim']),
            nn.ReLU(),
            nn.LayerNorm(kp_cfg['model_dim'])
        )

        # 4. Fusion Core (Cross-Attention)
        self.fusion_cross_attention = nn.MultiheadAttention(
            embed_dim=fusion_cfg['embed_dim'],
            num_heads=fusion_cfg['num_heads'],
            dropout=fusion_cfg['dropout'],
            batch_first=True
        )

        # 5. Final Prediction Head
        # The fused dimension will be the sum of the image and the context-aware Qgrid features
        fused_dim = self.image_encoder.d_model + fusion_cfg['embed_dim']
        self.ctc_head = nn.Linear(fused_dim, num_classes)

    def forward(self, images, qgrids, keypoints):
        """
        images: (B, T_img, C_img, H, W)
        qgrids: (B, T_qgrid, C_qgrid, H_q, W_q) - Note: T_qgrid can be much larger than T_img
        keypoints: (B, T_img, Num_Joints * Dims)
        """
        # Encode each modality
        image_features = self.image_encoder(images)  # (B, T_img, D_img)
        qgrid_features = self.qgrid_encoder(qgrids)  # (B, T_qgrid, D_qgrid)
        keypoint_features = self.keypoint_encoder(keypoints) # (B, T_img, D_kp)

        # Fuse keypoints with image features early on
        low_freq_features = image_features + keypoint_features

        # Cross-Attention Fusion
        # The low-frequency features (Query) attend to the high-frequency features (Key, Value)
        qgrid_context, _ = self.fusion_cross_attention(
            query=low_freq_features,
            key=qgrid_features,
            value=qgrid_features
        )

        # Concatenate the original low-frequency features with the new context from the Qgrid
        final_fused_features = torch.cat([low_freq_features, qgrid_context], dim=-1)

        # Get final predictions for CTC loss
        logits = self.ctc_head(final_fused_features)
        
        # The output needs to be in the shape (T, B, C) for CTC loss
        return logits.permute(1, 0, 2)