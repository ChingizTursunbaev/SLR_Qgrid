# slr/datasets/multi_modal_datasets.py

import os
import torch
from torch.utils.data import Dataset
import numpy as np
import json
from PIL import Image
import csv # Using csv for the metadata files

class MultiModalPhoenixDataset(Dataset):
    # [MODIFIED] --- Added 'split' to the constructor ---
    def __init__(self, image_prefix, qgrid_prefix, kp_path, meta_dir, gloss_dict_path, split='train', transforms=None):
        self.image_prefix = image_prefix
        self.qgrid_prefix = os.path.join(qgrid_prefix, split) # Path to the correct split folder
        self.transforms = transforms
        self.split = split

        # Load gloss dictionary
        self.gloss_dict = np.load(gloss_dict_path, allow_pickle=True).item()
        
        # [MODIFIED] --- Load keypoints differently ---
        # The keypoints .pkl file likely contains all splits, so we load the whole thing
        all_keypoints_data = pickle.load(open(kp_path, 'rb'))
        
        # Load metadata and build the list of samples for the correct split
        # This now correctly handles the .csv format
        meta_path = os.path.join(meta_dir, f'phoenix2014.{split}.corpus.csv')
        self.samples = []
        self.keypoints_data = {}
        with open(meta_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f, delimiter='|')
            next(reader, None) # Skip header
            for row in reader:
                video_id = row[0]
                self.samples.append({
                    'id': video_id,
                    'folder': os.path.join(split, video_id), # e.g., train/video-id
                    'gloss': row[3] # Assuming gloss is the 4th column
                })
                # Find the matching keypoint data
                for complex_key, data in all_keypoints_data.items():
                    if video_id in complex_key:
                        self.keypoints_data[video_id] = data
                        break
        # ---

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        sample_info = self.samples[index]
        video_id = sample_info['id']

        # 1. [MODIFIED] --- Correctly construct the image folder path ---
        image_folder = os.path.join(self.image_prefix, sample_info['folder'])
        # ---
        
        image_files = sorted(os.listdir(image_folder))
        images = []
        for img_file in image_files:
            # Using try-except to handle potentially corrupted images
            try:
                img = Image.open(os.path.join(image_folder, img_file)).convert('RGB')
                images.append(img)
            except Exception as e:
                print(f"Warning: Could not load image {os.path.join(image_folder, img_file)}. Skipping. Error: {e}")
                continue
        
        if not images:
            # Handle case where a folder has no valid images
            # Return a dummy sample or raise an error
            return self.__getitem__((index + 1) % len(self))

        if self.transforms:
            images = self.transforms(images)

        # 2. Load Qgrid data
        qgrid_path = os.path.join(self.qgrid_prefix, f"{video_id}.npy")
        qgrid = torch.from_numpy(np.load(qgrid_path)).float()

        # 3. Load Keypoints
        keypoints = torch.from_numpy(self.keypoints_data[video_id]).float()
        keypoints = keypoints.reshape(keypoints.size(0), -1)

        # 4. Load Labels
        gloss_sequence = sample_info['gloss'].split()
        labels = torch.LongTensor([self.gloss_dict.get(g, self.gloss_dict['<unk>']) for g in gloss_sequence])

        return images, qgrid, keypoints, labels

def multi_modal_collate_fn(batch):
    # Separate the modalities
    images, qgrids, keypoints, labels = zip(*batch)

    # Pad sequences to the max length in the batch for each modality
    # Note: `pad_sequence` expects (T, *) shape, so we use batch_first=True
    padded_images = torch.nn.utils.rnn.pad_sequence(images, batch_first=True, padding_value=0.0)
    padded_qgrids = torch.nn.utils.rnn.pad_sequence(qgrids, batch_first=True, padding_value=0.0)
    padded_keypoints = torch.nn.utils.rnn.pad_sequence(keypoints, batch_first=True, padding_value=0.0)
    padded_labels = torch.nn.utils.rnn.pad_sequence(labels, batch_first=True, padding_value=0)

    # Get the original lengths for CTC loss
    image_lengths = torch.LongTensor([len(img) for img in images])
    label_lengths = torch.LongTensor([len(lbl) for lbl in labels])

    return padded_images, padded_qgrids, padded_keypoints, padded_labels, image_lengths, label_lengths